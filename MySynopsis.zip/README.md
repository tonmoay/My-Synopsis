# My-Synopsis
A Faculty Profile Builder
